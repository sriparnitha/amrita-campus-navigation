AMRITA SMART CAMPUS NAVIGATOR — PROTOTYPE

This is a mobile-friendly website prototype with:
- Searchable list of the 42 places visible in the supplied campus map
- Destination selection
- The supplied campus map displayed on the page

IMPORTANT:
- This is not yet a hosted website. The QR code must point to a public HTTPS website URL to work from anywhere.
- This prototype does not yet provide verified turn-by-turn routes or accurately highlight individual buildings.
- To use it: publish the contents of this folder using a static hosting service such as GitHub Pages or Netlify, then create ONE QR code containing the published URL.
- Verify all locations and walking paths with the campus before public deployment.
